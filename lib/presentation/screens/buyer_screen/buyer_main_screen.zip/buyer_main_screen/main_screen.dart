import 'package:flutter/material.dart';
import '../../../utils/utils.dart';
import '../../user_screen/inbox/inbox_screen.dart';
import '../../user_screen/order/buyer_seller_order_screen.dart';
import '../dashboard/seller_dashboard_screen.dart';
import '../more/seller_more_screen.dart';
import '../order/seller_order_screen.dart';
import 'component/bottom_navigation_bar.dart';
import 'component/main_controller.dart';

class BuyerMainScreen extends StatefulWidget {
  const BuyerMainScreen({super.key});

  @override
  State<BuyerMainScreen> createState() => _BuyerMainScreenState();
}

class _BuyerMainScreenState extends State<BuyerMainScreen> {
  final _homeController = MainController();
  late List<Widget> screenList;

  @override
  void initState() {
    super.initState();
    screenList = [
      const SellerDashboardScreen(),
      const InboxScreen(),
      const BuyerSellerOrderScreen(),
      // const SellerOrderScreen(),
       const BuyerMoreScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    // final dCubit = context.read<DashboardCubit>();
    return WillPopScope(
      onWillPop: () async {
        Utils.exitFromAppDialog(context);
        return true;
      },
      child: Scaffold(
        body: StreamBuilder<int>(
          initialData: 0,
          stream: _homeController.naveListener.stream,
          builder: (context, AsyncSnapshot<int> snapshot) {
            int item = snapshot.data ?? 0;
            return screenList[item];
          },
        ),
        bottomNavigationBar: const MyBottomNavigationBar(),
        // bottomNavigationBar: BlocBuilder<DashboardCubit, DashboardState>(
        //   builder: (context, state) {
        //     if (state is DashboardStateLoaded) {
        //       return const MyBottomNavigationBar();
        //     }
        //     if (dCubit.dashboardModel != null) {
        //       return const MyBottomNavigationBar();
        //     } else {
        //       return const SizedBox.shrink();
        //     }
        //   },
        // ),
      ),
    );
  }
}
